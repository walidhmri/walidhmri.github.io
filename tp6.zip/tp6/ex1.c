#include <stdio.h>
#include <stdlib.h>

int main(){
int tab[3][5], i,j;
for(i =0; i<3;i++)
{
    for(j=0;j<5;j++){
        scanf("%d",&tab[i][j]);
    }
} 
for(i =0; i<3;i++)
{
    for(j=0;j<5;j++){
        printf("%d\t",tab[i][j]);
    }
}
return 0;
}