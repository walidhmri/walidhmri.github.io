#include <stdio.h>
#include <stdlib.h>

int main(){
int tab[10], i,j,k,n;
scanf("%d",&n);
for(i =0; i<n;i++)
{
    scanf("%d",&tab[i]);
}
for (i = 0; i < n; i++)
{
    for (j = i + 1; j < n;)
    {
        if (tab[j] == tab[i])
        {
            for (k = j; k < n; k++)
            {
                tab[k] = tab[k + 1];
            }
            n--;
        }
        else
        {
            j++;
        }
    }
}
for(i =0; i<n;i++){
    printf("%d\t",tab[i]);}


return 0;
}