#include <stdio.h>
int main() {
  int n,s=0,r,o;
    printf("Entrer un entier: ");
    scanf("%d", &n);
    o = n;
    while (n != 0) {
        r = n % 10;
        s = s * 10 + r;
        n /= 10;
    }
    if (o == s)
        printf("%d est'un nombre palindrome.", o);
    else
        printf("%d pas un nombre  palindrome.", o);
    return 0;
}