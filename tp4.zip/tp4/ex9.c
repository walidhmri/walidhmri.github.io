#include <stdio.h>

int main(){
int i,n,s=0,p=0,v;
printf("Entrer un nombre : ");
scanf("%d",&n);
v =n;
  while (n  != 0)
  {
   s = n%10;
   n /= 10;
   p += s;
  }
  printf("La somme est des chiffres de  %d :%d",v,p);
 return 0;  
}