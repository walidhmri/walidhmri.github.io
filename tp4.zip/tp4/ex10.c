#include <stdio.h>
#include <stdlib.h>
int main(){
int Tab[20],i,n;
char c;
Tab[0] = 1;
Tab[1] = 1;
for(i=2;i<20;i=i+1) {
Tab[i] = Tab[i-1] + Tab[i-2];
}
printf("%d",Tab[19]);
getchar();
return 0;
} 