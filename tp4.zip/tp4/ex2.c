#include <stdio.h>

int main(){
int n,i;
printf("Enter un nombre :");
scanf("%d",&n);
for(i=0;i<=n;i++){
    if (i%2==0){printf("%d \t",i);}
}  
 return 0;  
}