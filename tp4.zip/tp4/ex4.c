#include <stdio.h>

int main()
{
    int n, i, c, somme = 0;
    float m;
    // le nombres des nombres n s
    // les nombre s
    printf("Enter le nombres des matiére puis écrire  le nombre de chacun :");
    scanf("%d", &c);
    for (i = 0; i < c; i++)
    {
        scanf("%d", &n);
        somme += n;
    }
    m = (float)somme / (float)c;
    printf("%.2f", m);
    return 0;
}
