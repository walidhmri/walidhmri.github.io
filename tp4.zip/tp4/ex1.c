#include <stdio.h>

int main(){
int i;
for(i=0;i<100;i = i+3){
    printf("%d \t",i);
}  
 return 0;  
}