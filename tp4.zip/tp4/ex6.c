#include <stdio.h>

int main(){
char i;
for(i='a';i<='j';i++){
    printf("%c \t",i);
}
 return 0;  
}