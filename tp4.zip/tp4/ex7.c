#include <stdio.h>
int main() {
  int n;
  int i = 0;
  printf("Entrer un entier : ");
  scanf("%d", &n);

  do {
    n /= 10;
    ++i;
  } while (n != 0);

  printf("Les nombres sont : %d",i);
}
