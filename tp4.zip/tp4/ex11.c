#include <stdio.h>
int main()
{
    int n, m;
    char c='*';
    int i,j;
    printf("Entrer deux entier : ");
    scanf("%d%d", &n, &m);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            printf(" * ");
        }
        printf("\n");
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j--)
        {
            printf("%c",c);
        }
        printf("\n");
    }



    return 0;
}
