#include <stdio.h>

int main () {
int tab[4] ,i;
for (i=0 ; i<4; i++)
{
    scanf("%d",&tab[i]);
    
}
for (i=3 ; i>=0; i--)
{
    printf(" tab 2 = %d\n",tab[i]);

}
return 0;
}