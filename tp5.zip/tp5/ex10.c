#include <stdio.h>
#include <string.h>

int main () {
int i=0,let=1,nb=0,sp=0;
char chaine[50] ;
gets(chaine);
for(i=0 ; i<50;i++){
if (chaine[i]== ' '){
    let = let + 1;
}
}
printf(" les nombre %d",let);

return 0;
}