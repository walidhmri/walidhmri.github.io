#include <stdio.h>
#include <string.h>

int main()
{
    int i = 0, let = 0, nb = 0, sp = 0;
    char chaine[20];
    gets(chaine);
    do 
    {
        if (chaine[i] >= 'a' && chaine[i] <= 'z')
        {
            let = let + 1;
        }
        if ((chaine[i] >= 1 && chaine[i] <= 47) || (chaine[i] >= 58 && chaine[i] < 65) || (chaine[i] == 91 && chaine[i] < 97) || (chaine[i] == 123 && chaine[i] <= 223))
        {
            sp = sp + 1;
        }

        if(chaine[i]>= 48 && chaine[i]<=57)
        {
            nb = nb + 1;
        }
        i++;}
    while (chaine[i] != '\0');
    printf(" les nombre%d les caract %d les spicial %d", nb, let, sp);

    return 0;
}