#include <stdio.h>
#include <math.h>
#include <stdio.h>
int main()
{
  int tab[5], tab2[5], i, s, t;
  for (i = 0; i < 5; i++)
  {
    scanf("%d", &tab[i]);
    tab2[i] = tab[i];
  }
  for (i = 0; i < 5; i++)
  {
    if (tab[0] < tab[i])
    {

      tab[0] = tab[i];
    }
    if (tab2[0] > tab2[i])
    {
      tab2[0] = tab2[i];
    }
  }
  printf("le max est : %d \nle min est %d", tab[0], tab2[0]);
  return 0;
}