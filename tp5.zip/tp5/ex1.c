#include <stdio.h>

int main () {
int tab[10] ,i;
for (i=0 ; i<10; i++)
{
    scanf("%d",&tab[i]);

}
for (i=0 ; i<10; i++)
{
    printf("%d",tab[i]);

}
return 0;
}