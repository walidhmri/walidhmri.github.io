#include <stdio.h>

int main () {
int tab[10] ,tab2[10],i;
for (i=0 ; i<10; i++)
{
    scanf("%d",&tab[i]);
    tab2[i] = tab[i];
}
for (i=0 ; i<10; i++)
{
    printf(" tab 2 = %d\n",tab2[i]);

}
return 0;
}