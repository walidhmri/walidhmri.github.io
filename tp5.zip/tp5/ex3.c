#include <stdio.h>

int main () {
int tab[10] ,i,somme=0;
for (i=0 ; i<10; i++)
{
    scanf("%d",&tab[i]);
    somme += tab[i];


}

    printf("%d",somme);

return 0;
}