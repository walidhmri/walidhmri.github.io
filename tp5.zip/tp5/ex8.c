#include <stdio.h>
#include <string.h>

int main () {
int i=0;
char chaine[10] ;
gets(chaine);
while(chaine[i] != '\0'){
    i++;
}
printf("%d",i);

return 0;
}