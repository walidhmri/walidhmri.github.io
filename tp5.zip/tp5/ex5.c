#include <stdio.h>

int main()
{
    int tab[10], i, p = 0, imp = 0;
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &tab[i]);
    }
    for (i = 0; i < 10; i++)
    {
        if (tab[i] % 2 == 0)
        {
            p = p + 1;
        }
        else
            imp = imp + 1;
    }
    printf("impair %d\n", imp);
    printf("le pair %d \n", p);
    return 0;
}